/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.faindmap;

/**
 *
 * @author Guilherme Cezarine
 */
public class Aresta {
  public int cod_aresta;
  public int are_origem;
  public int are_destino;
  public String are_direcao;
  public double are_distancia;
}
