/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.faindmap;

import java.util.ArrayList;
import java.util.Map;
import java.util.Queue;

/**
 *
 * @author Guilherme Cezarine
 */
public class FaindMap {

    public static void main(String[] args) {
        Grafo grafo = new Grafo();
        Aresta aresta = new Aresta();
        
        for (int i = 0; i < 5; i++) {
            Vertice vertice = new Vertice();
            vertice.cod_vertice = i + 1;
            vertice.ver_nome = "Sala " + i;
            vertice.cod_andar = i + 1;
            vertice.cod_bloco = i + 1;
            vertice.cod_campos = i + 1;
            grafo.adicionarVertice(vertice);
        }
        
        for (int i = 0; i < grafo.vertices.size(); i++) { 
            if (i==0) {
                aresta.are_origem   = 1;
                aresta.are_destino  = 2;
                aresta.are_distancia= 10;
                aresta.cod_aresta   = i+1;
                grafo.adicionarAresta(aresta);

                aresta.are_origem   = 2;
                aresta.are_destino  = 1;
                aresta.are_distancia= 10;
                aresta.cod_aresta   = i+1;
                grafo.adicionarAresta(aresta);              
            }
            
            if (i==1) {
                aresta.are_origem   = 1;
                aresta.are_destino  = 4;
                aresta.are_distancia= 32;
                aresta.cod_aresta   = i+1;
                grafo.adicionarAresta(aresta);

                aresta.are_origem   = 4;
                aresta.are_destino  = 1;
                aresta.are_distancia= 32;
                aresta.cod_aresta   = i+1;
                grafo.adicionarAresta(aresta);
            }
                    
             if (i==2) {
                aresta.are_origem   = 2;
                aresta.are_destino  = 3;
                aresta.are_distancia= 19;
                aresta.cod_aresta   = i+1;
                grafo.adicionarAresta(aresta);
                
                aresta.are_origem   = 3;
                aresta.are_destino  = 2;
                aresta.are_distancia= 19;
                aresta.cod_aresta   = i+1;
                grafo.adicionarAresta(aresta);
                
                aresta.are_origem   = 3;
                aresta.are_destino  = 4;
                aresta.are_distancia= 5;
                aresta.cod_aresta   = i+1;
                grafo.adicionarAresta(aresta);
                
                aresta.are_origem   = 4;
                aresta.are_destino  = 3;
                aresta.are_distancia= 5;
                aresta.cod_aresta   = i+1;
                grafo.adicionarAresta(aresta);
            }
            if (i==3) {
                aresta.are_origem   = 4;
                aresta.are_destino  = 5;
                aresta.are_distancia= 13;
                aresta.cod_aresta   = i+1;
                grafo.adicionarAresta(aresta);
                
                aresta.are_origem   = 5;
                aresta.are_destino  = 4;
                aresta.are_distancia= 13;
                aresta.cod_aresta   = i+1;
                grafo.adicionarAresta(aresta);
            }
        }
        
        int LInicio = 1;
        int LFim = 4;
        double LDistancia = 0.00;
        ArrayList<Aresta> LCaminhos;
        LCaminhos = grafo.dijkstra(LInicio, LFim);
        
        for (int i = 0; i < LCaminhos.size(); i++) {
            System.out.println("Origem: " + LCaminhos.get(i).are_origem + " Destino: " +  LCaminhos.get(i).are_destino + " Distancia: " + LCaminhos.get(i).are_distancia); 
            LDistancia += LCaminhos.get(i).are_distancia;
        }
       
        
        System.out.println("De: " + LInicio + " para " + LFim + " a distancia é de: " + LDistancia);
                
 /*       for (Map.Entry<Integer, Vertice> entrada : distancias.entrySet()) {
            int destino = entrada.getKey();
            LDistancia = entrada.getValue().peso;
            System.out.println("Distância de " + LInicio + " para " + destino + ": " + LDistancia);
        }*/
    }
}
